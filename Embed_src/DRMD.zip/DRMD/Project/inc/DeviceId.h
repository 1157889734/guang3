#ifndef DeviceId_H_
#define DeviceId_H_




extern u8 gDeviceId;

extern void LedDispId(void);
extern void GetDeviceId(void);

#endif


