#ifndef __UDP_SERVER_H
#define __UDP_SERVER_H


extern void send_int_buf_by_udp(unsigned char *buf, int length);
extern void udp_server_init(void);
#endif
